﻿namespace TicTacToe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menu = new System.Windows.Forms.Panel();
            this.CBcustom = new System.Windows.Forms.CheckBox();
            this.CBdefult = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Splayer = new System.Windows.Forms.Label();
            this.play = new System.Windows.Forms.Button();
            this.CossePlayer_O = new System.Windows.Forms.Button();
            this.CossePlayer_X = new System.Windows.Forms.Button();
            this.LchoosePlayer = new System.Windows.Forms.Label();
            this.Lmenu = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Lties = new System.Windows.Forms.Label();
            this.Lwinns = new System.Windows.Forms.Label();
            this.Lgamesplayed = new System.Windows.Forms.Label();
            this.Lloses = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.B9 = new System.Windows.Forms.Button();
            this.B6 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B8 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.B7 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.Controls.Add(this.CBcustom);
            this.menu.Controls.Add(this.CBdefult);
            this.menu.Controls.Add(this.label7);
            this.menu.Controls.Add(this.Splayer);
            this.menu.Controls.Add(this.play);
            this.menu.Controls.Add(this.CossePlayer_O);
            this.menu.Controls.Add(this.CossePlayer_X);
            this.menu.Controls.Add(this.LchoosePlayer);
            this.menu.Controls.Add(this.Lmenu);
            this.menu.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu.Location = new System.Drawing.Point(258, 455);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(63, 29);
            this.menu.TabIndex = 17;
            // 
            // CBcustom
            // 
            this.CBcustom.AutoSize = true;
            this.CBcustom.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBcustom.Location = new System.Drawing.Point(27, 348);
            this.CBcustom.Name = "CBcustom";
            this.CBcustom.Size = new System.Drawing.Size(78, 27);
            this.CBcustom.TabIndex = 7;
            this.CBcustom.Text = "Custom";
            this.CBcustom.UseVisualStyleBackColor = true;
            this.CBcustom.CheckedChanged += new System.EventHandler(this.CBcustom_CheckedChanged);
            // 
            // CBdefult
            // 
            this.CBdefult.AutoSize = true;
            this.CBdefult.Checked = true;
            this.CBdefult.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CBdefult.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBdefult.Location = new System.Drawing.Point(27, 315);
            this.CBdefult.Name = "CBdefult";
            this.CBdefult.Size = new System.Drawing.Size(69, 27);
            this.CBdefult.TabIndex = 7;
            this.CBdefult.Text = "Defult";
            this.CBdefult.UseVisualStyleBackColor = true;
            this.CBdefult.CheckedChanged += new System.EventHandler(this.CBdefult_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(21, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(156, 36);
            this.label7.TabIndex = 6;
            this.label7.Text = "Change Color";
            // 
            // Splayer
            // 
            this.Splayer.AutoSize = true;
            this.Splayer.Font = new System.Drawing.Font("Segoe Print", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Splayer.ForeColor = System.Drawing.Color.Red;
            this.Splayer.Location = new System.Drawing.Point(29, 231);
            this.Splayer.Name = "Splayer";
            this.Splayer.Size = new System.Drawing.Size(49, 21);
            this.Splayer.TabIndex = 4;
            this.Splayer.Text = "Status";
            this.Splayer.Visible = false;
            // 
            // play
            // 
            this.play.Location = new System.Drawing.Point(432, 430);
            this.play.Name = "play";
            this.play.Size = new System.Drawing.Size(94, 48);
            this.play.TabIndex = 3;
            this.play.Text = "Play";
            this.play.UseVisualStyleBackColor = true;
            this.play.Click += new System.EventHandler(this.play_Click);
            // 
            // CossePlayer_O
            // 
            this.CossePlayer_O.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CossePlayer_O.Font = new System.Drawing.Font("Segoe Print", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CossePlayer_O.Location = new System.Drawing.Point(154, 147);
            this.CossePlayer_O.Name = "CossePlayer_O";
            this.CossePlayer_O.Size = new System.Drawing.Size(97, 76);
            this.CossePlayer_O.TabIndex = 2;
            this.CossePlayer_O.Text = "O";
            this.CossePlayer_O.UseVisualStyleBackColor = true;
            this.CossePlayer_O.Click += new System.EventHandler(this.CossePlayer_O_Click);
            // 
            // CossePlayer_X
            // 
            this.CossePlayer_X.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CossePlayer_X.Font = new System.Drawing.Font("Segoe Print", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CossePlayer_X.Location = new System.Drawing.Point(29, 147);
            this.CossePlayer_X.Name = "CossePlayer_X";
            this.CossePlayer_X.Size = new System.Drawing.Size(97, 76);
            this.CossePlayer_X.TabIndex = 2;
            this.CossePlayer_X.Text = "X";
            this.CossePlayer_X.UseVisualStyleBackColor = true;
            this.CossePlayer_X.Click += new System.EventHandler(this.CossePlayer_X_Click);
            // 
            // LchoosePlayer
            // 
            this.LchoosePlayer.AutoSize = true;
            this.LchoosePlayer.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LchoosePlayer.Location = new System.Drawing.Point(20, 101);
            this.LchoosePlayer.Name = "LchoosePlayer";
            this.LchoosePlayer.Size = new System.Drawing.Size(186, 42);
            this.LchoosePlayer.TabIndex = 1;
            this.LchoosePlayer.Text = "Choose Player";
            // 
            // Lmenu
            // 
            this.Lmenu.AutoSize = true;
            this.Lmenu.Font = new System.Drawing.Font("Segoe Print", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lmenu.Location = new System.Drawing.Point(184, 9);
            this.Lmenu.Name = "Lmenu";
            this.Lmenu.Size = new System.Drawing.Size(168, 85);
            this.Lmenu.TabIndex = 0;
            this.Lmenu.Text = "Menu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(381, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 20);
            this.label3.TabIndex = 25;
            this.label3.Text = "Ties";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 28);
            this.label4.TabIndex = 24;
            this.label4.Text = "Games Played :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(254, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 20);
            this.label2.TabIndex = 23;
            this.label2.Text = "Loses";
            // 
            // Lties
            // 
            this.Lties.AutoSize = true;
            this.Lties.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lties.Location = new System.Drawing.Point(421, 47);
            this.Lties.Name = "Lties";
            this.Lties.Size = new System.Drawing.Size(19, 20);
            this.Lties.TabIndex = 22;
            this.Lties.Text = "0";
            // 
            // Lwinns
            // 
            this.Lwinns.AutoSize = true;
            this.Lwinns.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lwinns.Location = new System.Drawing.Point(190, 47);
            this.Lwinns.Name = "Lwinns";
            this.Lwinns.Size = new System.Drawing.Size(19, 20);
            this.Lwinns.TabIndex = 21;
            this.Lwinns.Text = "0";
            // 
            // Lgamesplayed
            // 
            this.Lgamesplayed.AutoSize = true;
            this.Lgamesplayed.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lgamesplayed.Location = new System.Drawing.Point(147, 9);
            this.Lgamesplayed.Name = "Lgamesplayed";
            this.Lgamesplayed.Size = new System.Drawing.Size(24, 28);
            this.Lgamesplayed.TabIndex = 20;
            this.Lgamesplayed.Text = "0";
            // 
            // Lloses
            // 
            this.Lloses.AutoSize = true;
            this.Lloses.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lloses.Location = new System.Drawing.Point(305, 47);
            this.Lloses.Name = "Lloses";
            this.Lloses.Size = new System.Drawing.Size(19, 20);
            this.Lloses.TabIndex = 19;
            this.Lloses.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(139, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Winns";
            // 
            // B9
            // 
            this.B9.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B9.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B9.Location = new System.Drawing.Point(349, 318);
            this.B9.Name = "B9";
            this.B9.Size = new System.Drawing.Size(118, 99);
            this.B9.TabIndex = 16;
            this.B9.UseVisualStyleBackColor = true;
            this.B9.Click += new System.EventHandler(this.button_click);
            // 
            // B6
            // 
            this.B6.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B6.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B6.Location = new System.Drawing.Point(349, 190);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(118, 100);
            this.B6.TabIndex = 15;
            this.B6.UseVisualStyleBackColor = true;
            this.B6.Click += new System.EventHandler(this.button_click);
            // 
            // B3
            // 
            this.B3.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B3.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(349, 79);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(118, 83);
            this.B3.TabIndex = 14;
            this.B3.UseVisualStyleBackColor = true;
            this.B3.Click += new System.EventHandler(this.button_click);
            // 
            // B8
            // 
            this.B8.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B8.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B8.Location = new System.Drawing.Point(199, 318);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(122, 99);
            this.B8.TabIndex = 13;
            this.B8.UseVisualStyleBackColor = true;
            this.B8.Click += new System.EventHandler(this.button_click);
            // 
            // B5
            // 
            this.B5.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B5.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B5.Location = new System.Drawing.Point(199, 190);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(122, 100);
            this.B5.TabIndex = 12;
            this.B5.UseVisualStyleBackColor = true;
            this.B5.Click += new System.EventHandler(this.button_click);
            // 
            // B2
            // 
            this.B2.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B2.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(199, 79);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(122, 83);
            this.B2.TabIndex = 11;
            this.B2.UseVisualStyleBackColor = true;
            this.B2.Click += new System.EventHandler(this.button_click);
            // 
            // B1
            // 
            this.B1.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B1.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(74, 79);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(97, 83);
            this.B1.TabIndex = 10;
            this.B1.UseVisualStyleBackColor = true;
            this.B1.Click += new System.EventHandler(this.button_click);
            // 
            // B7
            // 
            this.B7.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B7.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B7.Location = new System.Drawing.Point(74, 318);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(97, 99);
            this.B7.TabIndex = 9;
            this.B7.UseVisualStyleBackColor = true;
            this.B7.Click += new System.EventHandler(this.button_click);
            // 
            // B4
            // 
            this.B4.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.B4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B4.Font = new System.Drawing.Font("Segoe Script", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.Location = new System.Drawing.Point(74, 190);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(97, 100);
            this.B4.TabIndex = 8;
            this.B4.UseVisualStyleBackColor = true;
            this.B4.Click += new System.EventHandler(this.button_click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Lime;
            this.pictureBox2.Location = new System.Drawing.Point(327, 79);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(16, 338);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Lime;
            this.pictureBox4.Location = new System.Drawing.Point(74, 296);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(393, 16);
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Lime;
            this.pictureBox3.Location = new System.Drawing.Point(74, 168);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(393, 16);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Lime;
            this.pictureBox1.Location = new System.Drawing.Point(177, 79);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(16, 338);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(391, 455);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 20);
            this.label5.TabIndex = 26;
            this.label5.Text = "Press F1 to restart";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe Script", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 455);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(198, 20);
            this.label6.TabIndex = 26;
            this.label6.Text = "Press ESC to open the Menu";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 484);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Lties);
            this.Controls.Add(this.Lwinns);
            this.Controls.Add(this.Lgamesplayed);
            this.Controls.Add(this.Lloses);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.B9);
            this.Controls.Add(this.B6);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.B8);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.B7);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Tic That Toe With some Tac";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Label Splayer;
        private System.Windows.Forms.Button play;
        private System.Windows.Forms.Button CossePlayer_O;
        private System.Windows.Forms.Button CossePlayer_X;
        private System.Windows.Forms.Label LchoosePlayer;
        private System.Windows.Forms.Label Lmenu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Lties;
        private System.Windows.Forms.Label Lwinns;
        private System.Windows.Forms.Label Lgamesplayed;
        private System.Windows.Forms.Label Lloses;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button B9;
        private System.Windows.Forms.Button B6;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B8;
        private System.Windows.Forms.Button B5;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button B7;
        private System.Windows.Forms.Button B4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox CBcustom;
        private System.Windows.Forms.CheckBox CBdefult;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

