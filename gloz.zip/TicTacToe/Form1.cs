﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        #region Varibles

        string player;
        string player_turn;
        bool win = false;

        List<Button> Winnig_formation = new List<Button>();

        #endregion

        #region Main Game

        public Form1()
        {
            InitializeComponent();
            menu.Dock = DockStyle.Fill;
        }
        
        private void button_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            if (player == "X")
            {

                if (player_turn == "X")
                {
                    button.Text = "X";
                    player_turn = "O";
                    button.Enabled = false;
                    Check_For_Win();
                    Computers_turn();

                }
            }

            else
            {
                if (player_turn == "O")
                {
                    button.Text = "O";
                    player_turn = "X";
                    button.Enabled = false;
                    Check_For_Win();
                    Computers_turn();

                }
            }
        }
        public void Check_For_Win()
        {
            if (B1.Text == "X" && B2.Text == "X" && B3.Text == "X" || B1.Text == "O" && B2.Text == "O" && B3.Text == "O")
            {
                win = true;
                Winnig_formation.Add(B1);
                Winnig_formation.Add(B2);
                Winnig_formation.Add(B3);

            }

            else if (B4.Text == "X" && B5.Text == "X" && B6.Text == "X" || B4.Text == "O" && B5.Text == "O" && B6.Text == "O")
            {
                win = true;
                Winnig_formation.Add(B4);
                Winnig_formation.Add(B5);
                Winnig_formation.Add(B6);


            }

            else if (B7.Text == "X" && B8.Text == "X" && B9.Text == "X" || B7.Text == "O" && B8.Text == "O" && B9.Text == "O")
            {
                win = true;
                Winnig_formation.Add(B7);
                Winnig_formation.Add(B8);
                Winnig_formation.Add(B9);


            }

            else if (B1.Text == "X" && B4.Text == "X" && B7.Text == "X" || B1.Text == "O" && B4.Text == "O" && B7.Text == "O")
            {
                win = true;
                Winnig_formation.Add(B1);
                Winnig_formation.Add(B4);
                Winnig_formation.Add(B7);


            }

            else if (B2.Text == "X" && B5.Text == "X" && B8.Text == "X" || B2.Text == "O" && B5.Text == "O" && B8.Text == "O")
            {
                win = true;
                Winnig_formation.Add(B2);
                Winnig_formation.Add(B5);
                Winnig_formation.Add(B8);


            }

            else if (B3.Text == "X" && B6.Text == "X" && B9.Text == "X" || B3.Text == "O" && B6.Text == "O" && B9.Text == "O")
            {
                win = true;
                Winnig_formation.Add(B3);
                Winnig_formation.Add(B6);
                Winnig_formation.Add(B9);


            }

            else if (B1.Text == "X" && B5.Text == "X" && B9.Text == "X" || B1.Text == "O" && B5.Text == "O" && B9.Text == "O")
            {
                win = true;
                Winnig_formation.Add(B1);
                Winnig_formation.Add(B5);
                Winnig_formation.Add(B9);
            }

            else if (B3.Text == "X" && B5.Text == "X" && B7.Text == "X" || B3.Text == "O" && B5.Text == "O" && B7.Text == "O")
            {
                win = true;
                Winnig_formation.Add(B3);
                Winnig_formation.Add(B5);
                Winnig_formation.Add(B7);

            }
            afterCheck();
        }

        #endregion

        #region Game settings

        private void CossePlayer_X_Click(object sender, EventArgs e)
        {
            if (CossePlayer_X.Text == "X")
            {
                player = "X";
                CossePlayer_X.FlatAppearance.BorderColor = Color.Red;
                CossePlayer_X.FlatAppearance.BorderSize = 3;

                CossePlayer_O.FlatAppearance.BorderColor = Color.Black;
                CossePlayer_O.FlatAppearance.BorderSize = 1;

                Splayer.Visible = false;
            }
        }

        private void CossePlayer_O_Click(object sender, EventArgs e)
        {

            if (CossePlayer_O.Text == "O")
            {
                player = "O";
                CossePlayer_O.FlatAppearance.BorderColor = Color.Lime;
                CossePlayer_O.FlatAppearance.BorderSize = 3;

                CossePlayer_X.FlatAppearance.BorderColor = Color.Black;
                CossePlayer_X.FlatAppearance.BorderSize = 1;

                Splayer.Visible = false;
            }
        }

        private void play_Click(object sender, EventArgs e)
        {
            if (player == null)
            {
                Splayer.Visible = true;
                Splayer.Text = "You must choose a player";
            }

            else
            {
                menu.Visible = false;
                player_turn = player;
            }
        }

        private void CBdefult_CheckedChanged(object sender, EventArgs e)
        {
            if (CBdefult.Checked)
            {
                CBcustom.Checked = false;

                pictureBox1.BackColor = Color.Lime;
                pictureBox2.BackColor = Color.Lime;
                pictureBox3.BackColor = Color.Lime;
                pictureBox4.BackColor = Color.Lime;
            }
        }

        private void CBcustom_CheckedChanged(object sender, EventArgs e)
        {
            if (CBcustom.Checked)
            {
                CBdefult.Checked = false;

                ColorDialog cd = new ColorDialog();
                if (cd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    pictureBox1.BackColor = cd.Color;
                    pictureBox2.BackColor = cd.Color;
                    pictureBox3.BackColor = cd.Color;
                    pictureBox4.BackColor = cd.Color;
                }
            }
        }

        #endregion

        #region Tools

        public async void Computers_turn()
        {
            if (B1.Text == "X" && B2.Text == "X" && B3.Text == "" || B1.Text == "O" && B2.Text == "O" && B3.Text == "")
            {
                await Task.Delay(350);
                B3.Text = player_turn;
                B3.Enabled = false;
                Check_For_Win();
            }

            else if (B3.Text == "X" && B2.Text == "X" && B1.Text == "" || B3.Text == "O" && B2.Text == "O" && B1.Text == "")
            {
                await Task.Delay(350);
                B1.Text = player_turn;
                B1.Enabled = false;
                Check_For_Win();
            }

            else if (B1.Text == "X" && B5.Text == "X" && B9.Text == "" || B1.Text == "O" && B5.Text == "O" && B9.Text == "")
            {
                await Task.Delay(350);
                B9.Text = player_turn;
                B9.Enabled = false;
                Check_For_Win();
            }

            else if (B9.Text == "X" && B5.Text == "X" && B1.Text == "" || B9.Text == "O" && B5.Text == "O" && B1.Text == "")
            {
                await Task.Delay(350);
                B1.Text = player_turn;
                B1.Enabled = false;
                Check_For_Win();
            }

            else if (B1.Text == "X" && B4.Text == "X" && B7.Text == "" || B1.Text == "O" && B4.Text == "O" && B7.Text == "")
            {
                await Task.Delay(350);
                B7.Text = player_turn;
                B7.Enabled = false;
                Check_For_Win();
            }

            else if (B7.Text == "X" && B5.Text == "X" && B1.Text == "" || B7.Text == "O" && B4.Text == "O" && B1.Text == "")
            {
                await Task.Delay(350);
                B1.Text = player_turn;
                B1.Enabled = false;
                Check_For_Win();
            }

            else if (B4.Text == "X" && B5.Text == "X" && B6.Text == "" || B4.Text == "O" && B5.Text == "O" && B6.Text == "")
            {
                await Task.Delay(350);
                B6.Text = player_turn;
                B6.Enabled = false;
                Check_For_Win();
            }

            else if (B6.Text == "X" && B5.Text == "X" && B4.Text == "" || B6.Text == "O" && B5.Text == "O" && B4.Text == "")
            {
                await Task.Delay(350);
                B4.Text = player_turn;
                B4.Enabled = false;
                Check_For_Win();
            }

            else if (B7.Text == "X" && B8.Text == "X" && B9.Text == "" || B7.Text == "O" && B8.Text == "O" && B9.Text == "")
            {
                await Task.Delay(350);
                B9.Text = player_turn;
                B9.Enabled = false;
                Check_For_Win();
            }

            else if (B9.Text == "X" && B8.Text == "X" && B7.Text == "" || B9.Text == "O" && B8.Text == "O" && B7.Text == "")
            {
                await Task.Delay(350);
                B7.Text = player_turn;
                B7.Enabled = false;
                Check_For_Win();
            }

            else if (B2.Text == "X" && B5.Text == "X" && B8.Text == "" || B2.Text == "O" && B5.Text == "O" && B8.Text == "")
            {
                await Task.Delay(350);
                B8.Text = player_turn;
                B8.Enabled = false;
                Check_For_Win();
            }

            else if (B8.Text == "X" && B5.Text == "X" && B2.Text == "" || B8.Text == "O" && B5.Text == "O" && B2.Text == "")
            {
                await Task.Delay(350);
                B2.Text = player_turn;
                B2.Enabled = false;
                Check_For_Win();
            }

            else if (B3.Text == "X" && B6.Text == "X" && B9.Text == "" || B3.Text == "O" && B6.Text == "O" && B9.Text == "")
            {
                await Task.Delay(350);
                B9.Text = player_turn;
                B9.Enabled = false;
                Check_For_Win();
            }

            else if (B9.Text == "X" && B6.Text == "X" && B3.Text == "" || B9.Text == "O" && B6.Text == "O" && B3.Text == "")
            {
                await Task.Delay(350);
                B3.Text = player_turn;
                B3.Enabled = false;
                Check_For_Win();
            }

            else if (B3.Text == "X" && B5.Text == "X" && B7.Text == "" || B3.Text == "O" && B5.Text == "O" && B7.Text == "")
            {
                await Task.Delay(350);
                B7.Text = player_turn;
                B7.Enabled = false;
                Check_For_Win();
            }

            else if (B7.Text == "X" && B5.Text == "X" && B3.Text == "" || B7.Text == "O" && B5.Text == "O" && B3.Text == "")
            {
                await Task.Delay(350);
                B3.Text = player_turn;
                B3.Enabled = false;
                Check_For_Win();
            }

            else if (B1.Text == "X" && B4.Text == "" && B7.Text == "X" || B1.Text == "O" && B7.Text == "O" && B4.Text == "")
            {
                await Task.Delay(350);
                B4.Text = player_turn;
                B4.Enabled = false;
                Check_For_Win();
            }
            else if (B7.Text == "X" && B9.Text == "X" && B8.Text == "" || B7.Text == "O" && B5.Text == "O" && B3.Text == "")
            {
                await Task.Delay(350);
                B8.Text = player_turn;
                B8.Enabled = false;
                Check_For_Win();
            }
            else if (B3.Text == "X" && B9.Text == "X" && B6.Text == "" || B7.Text == "O" && B5.Text == "O" && B3.Text == "")
            {
                await Task.Delay(350);
                B6.Text = player_turn;
                B6.Enabled = false;
                Check_For_Win();
            }

            else if (B5.Text == "")
            {
                await Task.Delay(350);
                B5.Text = player_turn;
                B5.Enabled = false;
                Check_For_Win();
            }

            else if (B1.Text == "")
            {
                await Task.Delay(350);
                B1.Text = player_turn;
                B1.Enabled = false;
                Check_For_Win();
            }

            else if (B2.Text == "")
            {
                await Task.Delay(350);
                B2.Text = player_turn;
                B2.Enabled = false;
                Check_For_Win();
            }

            else if (B3.Text == "")
            {
                await Task.Delay(350);
                B3.Text = player_turn;
                B3.Enabled = false;
                Check_For_Win();
            }

            else if (B4.Text == "")
            {
                await Task.Delay(350);
                B4.Text = player_turn;
                B4.Enabled = false;
                Check_For_Win();
            }

            else if (B5.Text == "")
            {
                await Task.Delay(350);
                B5.Text = player_turn;
                B5.Enabled = false;
                Check_For_Win();
            }

            else if (B6.Text == "")
            {
                await Task.Delay(350);
                B6.Text = player_turn;
                B6.Enabled = false;
                Check_For_Win();
            }

            else if (B7.Text == "")
            {
                await Task.Delay(350);
                B7.Text = player_turn;
                B7.Enabled = false;
                Check_For_Win();
            }

            else if (B8.Text == "")
            {
                await Task.Delay(350);
                B8.Text = player_turn;
                B8.Enabled = false;
                Check_For_Win();
            }

            else if (B9.Text == "")
            {
                await Task.Delay(350);
                B9.Text = player_turn;
                B9.Enabled = false;
                Check_For_Win();
            }

            if (player_turn == "X")
                player_turn = "O";

            else
                player_turn = "X";

        }

        public void Restart()
        {
            B1.Text = "";
            B1.Enabled = true;
            B2.Text = "";
            B2.Enabled = true;
            B3.Text = "";
            B3.Enabled = true;
            B4.Text = "";
            B4.Enabled = true;
            B5.Text = "";
            B5.Enabled = true;
            B6.Text = "";
            B6.Enabled = true;
            B7.Text = "";
            B7.Enabled = true;
            B8.Text = "";
            B8.Enabled = true;
            B9.Text = "";
            B9.Enabled = true;

            Winnig_formation[0].ForeColor = Color.Black;
            Winnig_formation[1].ForeColor = Color.Black;
            Winnig_formation[2].ForeColor = Color.Black;
            player_turn = player;
            win = false;
        }
            
        public async void Check_for_tie()
        {
            int Winns = Int32.Parse(Lwinns.Text);
            int Loses = Int32.Parse(Lloses.Text);
            int Ties = Int32.Parse(Lties.Text);

            if (B1.Text != "" && B2.Text != "" && B3.Text != "" && B4.Text != "" && B5.Text != "" && B6.Text != "" && B7.Text != "" && B8.Text != "" && B9.Text != "" &&
                win == false)
            {
                await Task.Delay(1000);
                Restart();
                Ties += 1;
                Lties.Text = Ties.ToString();

                Lgamesplayed.Text = (Winns + Loses + Ties).ToString();
            }
        }
        public async void Check_for_win()
        {
            int Winns = Int32.Parse(Lwinns.Text);
            int Loses = Int32.Parse(Lloses.Text);
            int Ties = Int32.Parse(Lties.Text);

            if (player == "X" && player_turn == "X" && win == true)
            {
                
                Lwinns.Text = Winns.ToString();
                Winnig_formation[0].ForeColor = Color.Lime;
                Winnig_formation[1].ForeColor = Color.Lime;
                Winnig_formation[2].ForeColor = Color.Lime;
                MessageBox.Show("Win");
                await Task.Delay(1000);
                Restart();
                Winns += 1;
            }

            if (player == "O" && player_turn == "O" && win == true)
            {
                
                Lwinns.Text = Winns.ToString();
                Winnig_formation[0].Enabled = true;
                Winnig_formation[1].Enabled = true;
                Winnig_formation[2].Enabled = true;

                Winnig_formation[0].ForeColor = Color.Lime;
                Winnig_formation[1].ForeColor = Color.Lime;
                Winnig_formation[2].ForeColor = Color.Lime;

                await Task.Delay(1000);
                Restart();
                Winns += 1;
            }
            

            Lgamesplayed.Text = (Winns + Loses + Ties).ToString();
        }
        public async void Check_for_losse()
        {
            int Winns = Int32.Parse(Lwinns.Text);
            int Loses = Int32.Parse(Lloses.Text);
            int Ties = Int32.Parse(Lties.Text);

            if(player == "X" && player_turn == "O" && win == true)
            {
                
                Lloses.Text = Loses.ToString();
                Winnig_formation[0].Enabled = true;
                Winnig_formation[1].Enabled = true;
                Winnig_formation[2].Enabled = true;

                Winnig_formation[0].ForeColor = Color.Red;
                Winnig_formation[1].ForeColor = Color.Red;
                Winnig_formation[2].ForeColor = Color.Red;
                MessageBox.Show("losse");
                await Task.Delay(1000);
                Restart();
                Loses += 1;
            }

            if(player == "O" && player_turn == "X" && win == true)
            {
                
                Lloses.Text = Loses.ToString();
                Winnig_formation[0].Enabled = true;
                Winnig_formation[1].Enabled = true;
                Winnig_formation[2].Enabled = true;

                Winnig_formation[0].ForeColor = Color.Red;
                Winnig_formation[1].ForeColor = Color.Red;
                Winnig_formation[2].ForeColor = Color.Red;

                await Task.Delay(1000);
                Restart();
                Loses += 1;
            }
            

            Lgamesplayed.Text = (Winns + Loses + Ties).ToString();

        }

        public void afterCheck()
        {
            Check_for_win();
            Check_for_tie();
            Check_for_losse();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F1:
                    Restart();
                    break;

                case Keys.Escape:
                    menu.Visible = true;
                    break;
            }
        }

        #endregion
    }
}

//Fix Winning machnisim
//Fix Losse/Win Color idanfactor
//Fix player: "O" 